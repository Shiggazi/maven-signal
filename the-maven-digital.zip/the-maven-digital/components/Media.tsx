import Image from 'next/image';
import {img} from '@/lib/sanity';
export default function Media({source,alt='',className='',width=1000,priority=false}:{source?:any,alt?:string,className?:string,width?:number,priority?:boolean}){const src=img(source,width);if(!src)return <div className={`image-placeholder ${className}`} aria-label={alt||'Image not uploaded yet'}><span>Upload image in Sanity Studio</span></div>;return <Image className={className} src={src} alt={source?.alt||alt} width={width} height={Math.round(width*1.1)} sizes="(max-width: 700px) 90vw, 35vw" priority={priority}/>}
