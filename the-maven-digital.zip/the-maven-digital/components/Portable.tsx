import {PortableText} from '@portabletext/react';
import Media from './Media';
export default function Portable({value}:{value?:any[]}){if(!value?.length)return null;return <div className="rich-text"><PortableText value={value} components={{types:{image:({value}:any)=><Media source={value} alt={value.alt||''} width={1200}/>},marks:{link:({children,value}:any)=><a href={value.href} rel="noopener noreferrer">{children}</a>}}}/></div>}
