import {createClient} from '@sanity/client';
import imageUrlBuilder from '@sanity/image-url';
const projectId=process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || 'missing';
const dataset=process.env.NEXT_PUBLIC_SANITY_DATASET || 'production';
export const configured=projectId!=='missing';
export const client=createClient({projectId,dataset,apiVersion:process.env.NEXT_PUBLIC_SANITY_API_VERSION||'2025-02-19',useCdn:false,token:process.env.SANITY_API_READ_TOKEN||undefined});
const builder=imageUrlBuilder(client);
export function img(source:any,w=1200){if(!configured||!source?.asset)return '';return builder.image(source).width(w).auto('format').url()}
export async function fetchSanity<T>(query:string,params:Record<string,unknown>={}):Promise<T|null>{if(!configured)return null;try{return await client.fetch<T>(query,params,{next:{revalidate:60}} as any)}catch(e){console.error('Sanity fetch failed',e);return null}}
export const settingsQ=`*[_type=="siteSettings"][0]{...,logo,footerLogo}`;
export const homeQ=`*[_type=="homePage"][0]{...}`;
export const collectionQ=(t:string)=>`*[_type=="${t}"] | order(coalesce(order,999) asc, _createdAt desc){...}`;
export const pageQ=`*[_type=="page" && slug.current==$slug][0]{...}`;
export const postQ=`*[_type=="post" && slug.current==$slug][0]{...}`;
