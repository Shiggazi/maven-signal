import {notFound} from 'next/navigation';
import {fetchSanity,postQ} from '@/lib/sanity';
import Media from '@/components/Media';
import Portable from '@/components/Portable';
import Link from 'next/link';
export async function generateMetadata({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const p:any=await fetchSanity(postQ,{slug});return {title:p?.seoTitle||p?.title||'Blog',description:p?.seoDescription||p?.excerpt}}
export default async function Article({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const p:any=await fetchSanity(postQ,{slug});if(!p||!p.publishedAt||new Date(p.publishedAt)>new Date())notFound();return <main><article className="article"><div className="article-head"><Link href="/blog" className="eyebrow">← BACK TO BLOG</Link><div className="eyebrow">{p.category} · {new Date(p.publishedAt).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</div><h1>{p.title}</h1><p>{p.excerpt}</p>{p.author&&<span>By {p.author}</span>}</div>{p.image&&<Media source={p.image} alt={p.title} width={1200}/>}<Portable value={p.body}/><div className="article-end"><Link className="pill" href="/blog">More articles <span className="pill-icon">↗</span></Link></div></article></main>}
