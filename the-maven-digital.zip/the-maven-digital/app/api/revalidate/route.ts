import {NextRequest,NextResponse} from 'next/server';
import {revalidatePath} from 'next/cache';
export async function POST(request:NextRequest){if(!process.env.SANITY_REVALIDATE_SECRET||request.headers.get('authorization')!==`Bearer ${process.env.SANITY_REVALIDATE_SECRET}`)return NextResponse.json({error:'Unauthorized'},{status:401});revalidatePath('/','layout');return NextResponse.json({revalidated:true})}
