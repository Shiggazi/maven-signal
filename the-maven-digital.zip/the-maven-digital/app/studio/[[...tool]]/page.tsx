'use client';
import {NextStudio} from 'next-sanity/studio';
import config from '@/sanity.config';
export default function Studio(){if(!process.env.NEXT_PUBLIC_SANITY_PROJECT_ID)return <div style={{padding:50}}>Configure Sanity environment variables to use Studio.</div>;return <NextStudio config={config}/>}
