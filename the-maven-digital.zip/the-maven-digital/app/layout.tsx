import type {Metadata} from 'next';
import './globals.css';
import {fetchSanity,settingsQ,collectionQ} from '@/lib/sanity';
import {baseSettings} from '@/lib/data';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
export async function generateMetadata():Promise<Metadata>{const s:any=await fetchSanity(settingsQ)||baseSettings;return {title:{default:s.seoTitle||s.brand||'The Maven Digital',template:`%s | ${s.brand||'The Maven Digital'}`},description:s.seoDescription||s.tagline,metadataBase:new URL(process.env.NEXT_PUBLIC_SITE_URL||'https://themavendigital.com.ng')}}
export default async function RootLayout({children}:{children:React.ReactNode}){const [settings,services,audiences]=await Promise.all([fetchSanity(settingsQ),fetchSanity<any[]>(collectionQ('service')),fetchSanity<any[]>(collectionQ('audience'))]);const s:any=settings||baseSettings;return <html lang="en"><body><Header settings={s} services={services||[]} audiences={audiences||[]}/>{children}<Footer settings={s}/></body></html>}
