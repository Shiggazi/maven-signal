# The Maven Digital | Next.js + Sanity + Vercel

Official brand domain: https://themavendigital.com.ng

Brand assets in `public/branding/`: `logo-light.png` for dark backgrounds, `logo-dark.png` for light backgrounds, and `logo-primary.png`. The header and footer use the light logo by default; logos can be replaced in Sanity Studio.

All initial content and prices are starter copy, not verified commercial offers. Update them in Sanity before publication.

# The Maven Digital style website: Next.js + Sanity + Vercel

A source-code starter implementing the **The Maven Digital design described in the supplied style guide**, with editable Sanity documents for most content, images, menus, services, audiences, portfolio, experts, packages, testimonials, general pages and blog posts. Blog posts are accessible at `/blog` and `/blog/[slug]`. The Sanity Studio is mounted at `/studio`.

> Important: This is not an exact copy of the original site. The original portraits, logo, project images, review media, all internal-page content and working integrations were not supplied. Upload your legally usable assets in Sanity Studio. This project does not recreate third-party sign-up, checkout, or voice recording functionality.

## 1. Create a Sanity project

1. Visit https://www.sanity.io/manage and create a project (dataset: `production`).
2. In Sanity project management, add `http://localhost:3000` and your deployed Vercel domain to the allowed CORS origins (credentials enabled for Studio login).
3. Create a token with **Editor** rights for the one-time seed script. Do not expose this token to browser code.
4. Copy `.env.example` to `.env.local` and fill in `NEXT_PUBLIC_SANITY_PROJECT_ID`, `NEXT_PUBLIC_SANITY_DATASET` and `SANITY_API_WRITE_TOKEN`.

## 2. Start locally

```bash
npm install
npm run dev
```

Open http://localhost:3000 for the site and http://localhost:3000/studio to log in and edit content. To seed the example copy and initial pricing/service structure:

```bash
npm run seed
```

The seed creates documents only if they don't exist. It will not overwrite your work. **Important:** the example copy and price numbers reflect the reference guide, and should be reviewed and replaced before launch. If you do not seed, the homepage shows fallback sample text, while images, projects and experts will remain empty until created in Sanity.

### Edit without code

- **Site Settings:** brand, logo, contact info, social links, navigation, footer and default SEO.
- **Homepage:** hero headings, cycling words, portrait images, all section introductions, stats, contact copy and CTAs.
- **Services and Audiences:** names, descriptions, image, bullet items and full page body.
- **Portfolio Projects:** titles, categories, featured image, gallery, external link, body.
- **Experts:** photo, badge, role, bio and links.
- **Pricing Plans:** prices, featured status, features and CTAs.
- **Testimonials & Proof:** only publish real, permissioned client proof.
- **General Pages:** about, authors and any other one-level route you want to publish; set the desired slug.
- **Blog Posts:** title, slug, author, category, publish date, excerpt, hero image, rich text, internal links and SEO text. A future publish date keeps the article out of the public blog until that date.

For image replacement, open the relevant document, select the image field, and upload a new file or choose one from your Sanity library. No code editing is required. The front-end uses Sanity's image CDN and refreshes fetched content on a ~60 second interval; optionally set up `/api/revalidate` for instant updates.

## 3. Deploy on Vercel

1. Put this folder into your own GitHub repository.
2. Import it at https://vercel.com/new as a Next.js project.
3. Add all public variables from `.env.example` to Vercel project environment variables. The private token `SANITY_API_WRITE_TOKEN` is only needed for seeding, not for normal operation. `SANITY_API_READ_TOKEN` is needed only for a private dataset; for public read access you may leave it empty.
4. Set `NEXT_PUBLIC_SITE_URL` to your deployed site URL and redeploy.
5. Add the deployed domain under Sanity API > CORS origins so the embedded Studio can authenticate.

The Studio's content schemas are version-controlled in this project. Editing schema structure (adding brand-new fields) requires a developer, but changing existing text, images, prices, pages and blog content does not.

## 4. Contact form email delivery

This project uses the Resend HTTP API directly to email submissions. Configure in Vercel:

- `RESEND_API_KEY` (secret)
- `CONTACT_EMAIL` (where messages arrive)
- `CONTACT_FROM_EMAIL` (an email on a domain verified in Resend)

Until all three exist, the form returns a clear delivery-unavailable error rather than falsely claiming to send. For production use add spam protection, request rate limiting and any necessary privacy/consent text. The form sends minimal details by email, not to Sanity.

## 5. Remaining work for a full production launch

- Upload the original or approved logo, fonts, portraits, reels, project screenshots and testimonials.
- Fill in the CMS with verified copy for all internal routes; generic one-level routes are created from `General Pages` documents.
- Add commerce/payment, signup, newsletter, voice messages and cookie management using services you own (these are not wired to the reference site's production endpoints).
- Connect Sanity Presentation/Visual Editing if you want click-to-edit overlays. This starter uses form-based Studio editing at `/studio`.
- Audit accessibility, privacy/cookie consent, security, responsiveness, SEO and performance before launch.
- Compare desktop/mobile screenshots against the live reference to achieve closer visual fidelity.

## Known gaps

The homepage includes a horizontally scrollable project reel rather than the original custom drag-to-angle interaction. The original delayed popup and cookie banner aren't replicated because their logic was not verified. Some content-only URLs fall back to a CMS-managed generic page, not individually recreated bespoke layouts. The styling uses Google Fonts rather than bundling the reference site's original font assets. All CMS-stored images are easy to replace, but the site's layout and animations still require code changes.
